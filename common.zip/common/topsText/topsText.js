(function () {
    'use strict';

    angular.module('wrapper.commonDirectives')
        .directive('topsText', function () {
            return {
                restrict: 'E',
                require: ['ngModel', '^form'],
                scope: {
                    args: '=',
                    name: '@',
                    skipvalidation:'@'
                },
                templateUrl: 'scripts/directives/common/topsText/topsText.html',
                link: function (scope, element, attrs, ctrl) {
                    var key, name;
                    var ngModel = ctrl[0];
                    // from model -> view
                    ngModel.$render = function () {
                        scope.model = ngModel.$viewValue;
                    };
                    // from view -> model
                    scope.onChange = function () {
                        ngModel.$setViewValue(scope.model);
                    };
                    // get form ctrl for html validation
                    scope.form = ctrl[1];
                    // show error based on no-init-validate attribute on form
                    scope.showError = !($(scope.form.$$element).is('[no-init-validate]'));
                    // get element properties and validation rules from args
                    scope.label = scope.args[0];
                    if (!scope.name) {
                        key = new RegExp(/\['(.*?)\']./).exec(attrs.ngModel);
                        name = (key && key.length) ? key[1] : (scope.label || Date.now());
                        scope.name = name.toLowerCase().replace(/\s/g, '');
                    }
                    scope.minlength = scope.args[1];
                    if (!!scope.args[2]) {
                        $(element).find('input').attr('maxlength', scope.args[2]);
                        scope.maxlength =scope.args[2];
                    }
                    scope.required = !!scope.args[3];
                    scope.pattern = (scope.args[4]) ? new RegExp(scope.args[4]) : new RegExp();

                    scope.class = scope.args[5] || (scope.label && 'col-md-3');
                    // set placeholder if provided
                    if (!!attrs.placeholder) {
                        $(element).find('input').attr('placeholder', attrs.placeholder);
                    }
                    //For all extra attributes
                    if (scope.args[6]) {
                        var extras = (scope.args[6]) ? scope.args[6] : '';
                        if (extras.indexOf('readOnly') !== -1) {
                            $(element).find('input').attr('readOnly', true);
                            scope.skipvalidation = 'yes';
                        }
                        if (extras.indexOf('uppercase') !== -1) {
                            $(element).find('input').attr('style', 'text-transform:uppercase');
                            ctrl[0].$parsers.push(function(input) {
                                return input ? input.toUpperCase() : '';
                            });
                        }
                    }
                    //Skip the validations when skipvalidation is yes
                    if (scope.skipvalidation && scope.skipvalidation === 'yes') {
                        scope.required = false;
                        scope.pattern = null;
                        scope.maxlength = null;
                    }
                }
            };
        });
})();