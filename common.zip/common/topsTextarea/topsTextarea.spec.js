'use strict';
describe('Directive: topsTextarea', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.commonDirectives'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        el = angular.element('<form> <tops-textarea ng-model="tests" args=["Street",1,100,true,"^[A-Za-z0-9]*$",2,"col-md-3"] name="test"></tops-textarea><form>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    //label, name, maxlength
    describe('Mapping args to view', function () {
        it('should map name ', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('textarea')).attr('name');
            expect(attrName).toBe('test');

        });
        it('should map label ', function () {

            expect(compiledElement()[0].querySelector('label').innerHTML).toEqual('Street');

        });
        it('should map maxLength ', function () {

            var attrName = angular.element(compiledElement()[0].querySelector('textarea')).attr('maxLength');
            // console.log(attrName);
            expect(attrName).toBe('100');

        });
    });
    describe('form validation', function () {
        it('required validation', function () {
            var  el = compiledElement();
            expect(el.hasClass('ng-valid-required')).toBeTruthy();
        });
        it('pattern validation', function () {
            var el = compiledElement('test144$$');
            expect(el.hasClass('ng-valid-pattern')).toBeTruthy();
        });
        it('minlength validation', function () {
            var el = compiledElement(null);
            expect(el.hasClass('ng-valid-minlength')).toBeTruthy();
        });
        it('maxlength validation', function () {
            var el = compiledElement('test1234');
            expect(el.hasClass('ng-valid-maxlength')).toBeTruthy();
        });

    });

});