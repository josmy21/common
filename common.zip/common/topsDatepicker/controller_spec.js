/**
 * Created by VUR4943 on 8/18/2015.
 */
'use strict';
describe('Unit testing startDueDatePicker Directive', function () {
    var $compile,
        $scope,
        $httpBackend,
        template,
        appService,
        $q,
        $timeout,
        form;
    // Load the search module, which contains the directive
    beforeEach(function () {
        module(function ($provide) {

            $provide.value('sfgEnvironmentService', {});
            $provide.value('$analytics', {});
            $provide.value('sfgApplication', {
                    isMockDataMode: true,
                    isAuthenticated: true
                }
            );

            $provide.value('sfgErrorModal', {});

            $provide.value('sfgApplicationLoggingService', {
                debug: function () {
                }
            });

        });
    });
    beforeEach(module('clientComm.model', 'applicationContext', 'app.Templates', 'clientComm.startDueDatePicker'));
    // Store references to $rootScope and $compile
    // so they are available to all tests in this describe block
    beforeEach(inject(function (policySummaryFactory, _$compile_, _$rootScope_, _$httpBackend_, _$q_, _$timeout_) {
        template = '/scripts/directives/startDueDatePicker/template.html';
        $scope = _$rootScope_;//.$new();
        $httpBackend = _$httpBackend_;
        $compile = _$compile_;
        // appService = _appService_;
        $q = _$q_;
        $timeout = _$timeout_;
        form = 'startDueDatePickerForm';

    }));
    var compiledElement = function () {
        var el;
        el = angular.element('<start-due-date-picker from-date="" to-date=""></start-due-date-picker>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };
    describe('A valid directive with scope', function () {

        it('should have a scope on root element', function () {
            var el = compiledElement();
            expect(el.isolateScope()).toBeDefined();
            expect(el.isolateScope().$id).not.toEqual($scope.$id);
        });
    });
});
