(function () {
    'use strict';

    describe('Unit Testing for Start Date and Due Date', function () {
        var moduleName = 'cosmo.startDueDatePicker';
        var $scope, $compile, templatePath, form, currentDateTimeFactory, $q, deferred;
        form = 'startDueDatePickerForm';
        templatePath = 'scripts/directives/startDueDatePicker/template.html';

        beforeEach(module(templatePath));
        beforeEach(module('ui.bootstrap.showErrors'));
        // Load the Create Work Item Module
        beforeEach(module(moduleName));

        // configure the $log message to display in the karma run console...
        beforeEach(module(moduleName, function ($provide) {
            // Output messages to the console
            $provide.value('$log', console);
        }));

        beforeEach(inject(function ($rootScope) {
            $scope = $rootScope;
        }));

        var compiledDirectiveElements = function () {
            var directiveElems;
            directiveElems = angular.element('<start-due-date-picker></start-due-date-picker>');
            inject(function ($compile) {
                directiveElems = $compile(directiveElems)($scope);
            });
            $scope.$digest();
            return directiveElems;
        };
        describe('Directive with scope', function () {

            it('should have an isolated scope', function () {
                var elem = compiledDirectiveElements();
                expect(elem.isolateScope()).toBeDefined();
            });
        });
        describe('Validation for Start Date and Due Date fields', function () {
            describe('Start Date', function () {
                var fieldName = 'startDate';
                it('should be a required field', function () {
                    var elem = compiledDirectiveElements();
                    var scope = elem.isolateScope();
                    scope.fromDate = '';
                    scope.$digest();
                    expect(scope[form][fieldName].$invalid).toBeTruthy();
                });

                it('should accept a valid date', function () {
                    var elem = compiledDirectiveElements();
                    var scope = elem.isolateScope();
                    /*scope.fromDate = '13/17/2015';
                     scope.$digest();
                     elem.find('#startDate').blur();
                     expect(scope[form][fieldName].$invalid).toBeTruthy();*/
                    scope.fromDate = '09/17/2015';
                    scope.$digest();
                    //elem.find('#startDate').blur();
                    expect(scope[form][fieldName].$valid).toBeTruthy();

                });

            });

            describe('Due Date', function () {
                var fieldName = 'dueDate';
                it('should be a required field', function () {
                    var elem = compiledDirectiveElements();
                    var scope = elem.isolateScope();
                    scope.toDate = '';
                    scope.$digest();
                    expect(scope[form][fieldName].$invalid).toBeTruthy();
                });
                it('should be greater than or equal to Start Date', function () {
                    var elem = compiledDirectiveElements();
                    var scope = elem.isolateScope();
                    scope.fromDate = '09/17/2015';
                    scope.toDate = '09/16/2015';
                    scope.$digest();
                    elem.find('#dueDate').blur();
                    expect(scope[form][fieldName].$invalid).toBeTruthy();
                    scope.fromDate = '09/17/2015';
                    scope.toDate = '09/18/2015';
                    scope.$digest();
                    elem.find('#dueDate').blur();
                    expect(scope[form][fieldName].$valid).toBeTruthy();
                });
                it('shouldn"t accept Saturday or Sunday', function () {
                    var elem = compiledDirectiveElements();
                    var scope = elem.isolateScope();
                    scope.fromDate = new Date('09/17/2015');
                    scope.toDate = new Date('09/19/2015'); //Saturday
                    scope.$digest();
                    elem.find('#dueDate').blur();
                    expect(scope[form][fieldName].$invalid).toBeTruthy();
                    scope.fromDate = new Date('09/17/2015');
                    scope.toDate = new Date('09/20/2015'); //Sunday
                    scope.$digest();
                    elem.find('#dueDate').blur();
                    expect(scope[form][fieldName].$invalid).toBeTruthy();

                });
            });

        });
    });
}());
