(function () {
    'use strict';

    /* globals moment: false */

    angular.module('wrapper.commonDirectives')
        .directive('topsDatepicker', ['$filter', function ($filter) {
            return {
                restrict: 'E',
                require: ['ngModel', '^form'],
                scope: {
                    args: '=',
                    name: '@',
                    pickerType: '@',
                    skipvalidation:'@'
                },
                templateUrl: 'scripts/directives/common/topsDatepicker/template.html',
                link: function (scope, element, attrs, ctrl) {
                    var key, name;
                    var ngModel = ctrl[0];
                    // Datepicker specific values
                    scope.dp = {
                        opened: false
                    };
                    scope.open = function () {
                        scope.dp.opened = !scope.dp.opened;
                    };
                    scope.format = 'MM/dd/yyyy';
                    scope.placeHoldetText = 'MM/DD/YYYY';
                    if (scope.pickerType === 'month') {
                        scope.dp.dateOptions = {
                            minMode: 'month',
                        };
                        scope.format = 'MM/yyyy';
                        scope.placeHoldetText = 'MM/YYYY';
                    }
                    if (scope.pickerType === 'monthYear') {
                        scope.dp.dateOptions = {
                            minMode: 'month',
                        };
                        scope.format = 'MM/yy';
                        scope.placeHoldetText = 'MM/YY';
                    }
                    if (scope.pickerType === 'mm-dd-yy') {
                        scope.format = 'MM-dd-yy';
                        scope.placeHoldetText = 'MM-DD-YY';
                    }
                    // from model -> view
                    ngModel.$render = function () {
                        if (ngModel.$viewValue) {
                            scope.dp.model = moment(ngModel.$viewValue, scope.format.toUpperCase()).toDate();
                        }
                        else {
                            scope.dp.model = '';
                        }
                    };
                    // from view -> model
                    scope.onChange = function () {
                        ngModel.$setViewValue($filter('date')(scope.dp.model, scope.format));
                        var datemodal = new Date(scope.dp.model);
                        var today =new Date();
                        if ((datemodal >today) && scope.args[4] === 'no-future') {
                            scope.form[scope.name].$setValidity('future', false);

                        }
                        else {
                            scope.form[scope.name].$setValidity('future', true);
                        }
                    };

                    // get form ctrl for html validation
                    scope.form = ctrl[1];
                    // show error based on no-init-validate attribute on form
                    scope.showError = !($(scope.form.$$element).is('[no-init-validate]'));
                    // get element properties and validation rules from args
                    scope.label = scope.args[0];
                    if (!scope.name) {
                        key = new RegExp(/\['(.*?)\']./).exec(attrs.ngModel);
                        name = (key && key.length) ? key[1] : (scope.label || Date.now());
                        scope.name = name.toLowerCase().replace(/\s/g, '');
                    }
                    scope.required = !!scope.args[1];
                    scope.class = scope.args[2] || (scope.label && 'col-md-3');
                    // For all extra attributes
                    if (scope.args[3]) {
                        var extras = (scope.args[3]) ? scope.args[3] : '';
                        if (extras.indexOf('readOnly') !== -1) {
                            $(element).find('input').attr('readOnly', true);
                            scope.skipvalidation = 'yes';
                        }
                    }
                    if (scope.args[4]) {
                        if (scope.args[4] === 'no-future') {
                            scope.dp.dateOptions = {
                                maxDate: new Date()
                            };

                        }
                    }
                    //Skip the validations when skipvalidation is yes
                    if (scope.skipvalidation && scope.skipvalidation === 'yes') {
                        scope.required = false;
                        scope.pattern = null;
                        scope.maxlength = null;
                    }
                }
            };
        }]);
}());