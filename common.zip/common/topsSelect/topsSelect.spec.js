'use strict';
describe('Directive: topsSelect', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.commonDirectives'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        $scope.rlob = [{
                'code': 'VP10',
                'description': 'VP10'
            },
            {
                'code': 'VP15',
                'description': 'VP15'
            },
            {
                'code': 'VP20',
                'description': 'VP20'
            },
            {
                'code': 'VP30',
                'description': 'VP30'
            },
            {
                'code': 'CGU3',
                'description': 'CGU3'
            }
        ];

        el = angular.element('<form><tops-select ng-model="tests" name="test" options="rlob" args=["Suffix",true,"col-md-1"]></tops-select><form>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    //label, name, maxlength
    describe('Mapping args to view', function () {
        it('should map name ', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('select')).attr('name');
            expect(attrName).toBe('test');

        });
        it('should map label ', function () {

            expect(compiledElement()[0].querySelector('label').innerHTML).toEqual('Suffix');

        });

    });
    describe('form validation', function () {
        it('required validation', function () {
            var el = compiledElement();
            expect(el.hasClass('ng-valid-required')).toBeTruthy();
        });

    });
    describe('options mapping', function () {
        it('should map options in select', function () {
            expect(angular.element(angular.element(compiledElement()[0].querySelector('select').innerHTML)[1]).attr('label')).toEqual('VP10');
        });
    });

});