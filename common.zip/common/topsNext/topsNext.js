(function () {
    'use strict';

    angular.module('wrapper.commonDirectives')
        .directive('topsNext', function () {
            return {
                restrict: 'E',

                scope: {
                    args: '='

                },
                templateUrl: 'scripts/directives/common/topsNext/topsNext.html',
                link: function (scope, element, attrs, ctrl) {

                    var key, name;

                    scope.next = function (evt) {
                    if (scope.args[0] === 'NextVertcal') {
                        scope.$emit('NextVertcal', scope.args[1] );
                    }
                    else if (scope.args[0] === 'nextHorizontal') {
                        scope.$emit('nextHorizontal', scope.args[1]);
                    }
                };
                }
            };
        });
})();