'use strict';
describe('Directive: topsAmount', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.commonDirectives'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        el = angular.element('<form><tops-amount ng-model="tests" args=["FaceAmount",1,10,false,"col-md-5"] name ="Amount"></tops-amount><form>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    //label, name, maxlength
    describe('Mapping args to view', function () {
        it('should map name ', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('input')).attr('name');
            expect(attrName).toBe('Amount');

        });
        it('should map label ', function () {

            expect(compiledElement()[0].querySelector('label').innerHTML).toEqual('FaceAmount');

        });
        it('should map maxLength ', function () {

            var attrName = angular.element(compiledElement()[0].querySelector('input')).attr('maxLength');
            // console.log(attrName);
            expect(attrName).toBe('10');

        });
    });
    describe('form validation', function () {
        it('required validation', function () {
            var el = compiledElement();
            expect(el.hasClass('ng-valid-required')).toBeTruthy();
        });
        it('pattern validation', function () {
            var el = compiledElement('120000');
            expect(el.hasClass('ng-valid-pattern')).toBeTruthy();
        });
        it('minlength validation', function () {
            var el = compiledElement('test');
            expect(el.hasClass('ng-valid-minlength')).toBeTruthy();
        });
        it('maxlength validation', function () {
            var el = compiledElement('123478791122');
            expect(el.hasClass('ng-valid-maxlength')).toBeTruthy();
        });

    });

});