'use strict';
describe('Directive: topsCheckbox', function () {
    var $compile;
    var $scope;

    beforeEach(module('wrapper.commonDirectives'));
    beforeEach(module('wrapper.Templates'));
    beforeEach(inject(function (_$compile_, _$rootScope_) {

        $compile = _$compile_;
        $scope = _$rootScope_;

    }));
    var compiledElement = function (val) {
        var el;
        $scope.tests = val;
        el = angular.element('<form> <tops-checkbox name="level" ng-model="tests" args=["Authorization","col-md-3"]></tops-checkbox><form>');
        el = $compile(el)($scope);
        $scope.$digest();
        return el;
    };

    //label, name, maxlength
    describe('Mapping args to view', function () {
        it('should map name ', function () {
            var attrName = angular.element(compiledElement()[0].querySelector('input')).attr('name');
            expect(attrName).toBe('level');

        });
        it('should map label ', function () {

            expect(compiledElement()[0].querySelector('span').innerHTML).toEqual('Authorization');

        });

    });

});