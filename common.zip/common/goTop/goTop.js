(function () {
    'use strict';

    angular.module('wrapper.commonDirectives')
        .directive('goTop', ['$window', function ($window) {
            return {
                restrict: 'E',
                scope: {},
                templateUrl: 'scripts/directives/common/goTop/goTop.html',
                link: function (scope, element, attrs, ctrl) {
                    var onScroll = function () {
                        if ($(this).scrollTop() > 100) {
                            $('#goToTop').fadeIn();
                        }
                        else {
                            $('#goToTop').fadeOut();
                        }
                    };
                    angular.element($window).on('scroll', onScroll);
                    scope.goToTop = function () {
                        $('html, body').animate({
                            scrollTop: 0
                        }, 500);
                        return false;
                    };
                    // unbind the scroll event for othe pages
                    scope.$on('$destroy', function () {
                        angular.element($window).off('scroll', onScroll);
                    });
                }
            };
        }]);
})();