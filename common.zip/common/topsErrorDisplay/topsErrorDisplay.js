(function () {
'use strict';

angular.module('wrapper.commonDirectives')
    .directive('topsErrorDisplay', function ($timeout) {
        return {
            restrict: 'E',
            require: ['^form'],
            templateUrl: 'scripts/directives/common/topsErrorDisplay/topsErrorDisplay.html',
            link: function (scope, element, attrs, ctrl) {

                scope.label =[];
                $timeout(function() {
                    angular.forEach(ctrl[0].$error.required, function(val, key) {
                        scope.label.push(val.$$attr.label);

                    });
                }, 0);

                scope.form = ctrl[0];
            }
        };
    });
})();
