(function () {
    'use strict';

    angular.module('wrapper.commonDirectives')
        .directive('topsTime', function () {
            return {
                restrict: 'E',
                require: ['ngModel', '^form'],
                scope: {
                    args: '=',
                    name: '@'
                },
                templateUrl: 'scripts/directives/common/topsTime/topsTime.html',
                link: function (scope, element, attrs, ctrl) {
                    var key, name;
                    var ngModel = ctrl[0];
                    // from model -> view
                    ngModel.$render = function() {
                        scope.model = ngModel.$viewValue;
                    };
                    // from view -> model
                    scope.onChange = function() {
                        ngModel.$setViewValue(scope.model);
                    };
                    // get form ctrl for html validation
                    scope.form = ctrl[1];
                    // show error based on no-init-validate attribute on form
                    scope.showError = !($(scope.form.$$element).is('[no-init-validate]'));
                    // get element properties and validation rules from args
                    scope.label = scope.args[0];
                    if (!scope.name) {
                        key = new RegExp(/\['(.*?)\']./).exec(attrs.ngModel);
                        name = (key && key.length) ? key[1] : (scope.label || Date.now());
                        scope.name = name.toLowerCase().replace(/\s/g, '');
                    }
                    scope.required = !!scope.args[1];
                    scope.class = scope.args[2] || (scope.label && 'col-md-3');
                    //For all extra attributes
                    if (scope.args[3]) {
                        var extras = (scope.args[3]) ? scope.args[3] : '';
                        if (extras.indexOf('readOnly') !== -1) {
                            $(element).find('input').attr('readOnly', true);
                        }
                    }
                }
            };
        });
})();